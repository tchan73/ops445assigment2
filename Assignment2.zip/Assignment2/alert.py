#!/usr/bin/env python3
# alert.py
# Author: Tania Chaudhary
# OPS445 Assignment 2 – Alerting System (Email)

import smtplib
import socket
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ==== Email Configuration ====
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587

SENDER_EMAIL = 'taniachaudhary2244@gmail.com'         # Replace with your Gmail address
SENDER_PASSWORD = 'bhga dhdk atux xxgh'         # Use Gmail App Password
RECIPIENT_EMAIL = 'tchaudhary3@myseneca.ca'     # Replace with recipient email

def send_email_alert(alerts, timestamp):
    """Send a system alert email with the provided alert messages."""

    hostname = socket.gethostname()

    subject = f"System Alert from {hostname}"
    body = f"""System Alert Detected at {timestamp}

Host: {hostname}

The following issues were detected:
{chr(10).join(f"- {alert}" for alert in alerts)}

Please check the system.
"""

    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = RECIPIENT_EMAIL
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.send_message(msg)
        server.quit()
        print(f"Alert email sent to {RECIPIENT_EMAIL}")
    except Exception as e:
        print(f"Failed to send alert email: {e}")


# Optional: Standalone test
if __name__ == '__main__':
    import datetime
    test_alerts = [
        "High CPU usage: 92%",
        "Disk usage exceeded 90% on /home"
    ]
    now = datetime.datetime.now().isoformat()
    send_email_alert(test_alerts, now)
