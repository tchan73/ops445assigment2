#!/usr/bin/env python3
# assignment2.py
# Main entry point for OPS445 Assignment 2 group project

import argparse
from scheduler import main as scheduler_main

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='System Monitoring and Alerting Tool'
    )
    parser.add_argument(
        '--interval', '-i',
        type=int,
        default=60,
        help='Interval in seconds between checks (default: 60)'
    )
    parser.add_argument(
        '--count', '-c',
        type=int,
        help='Number of checks to run before exiting (default: infinite)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Run without sending alerts (for testing purposes)'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Print full system status output (for testing purposes)'
    )

    args = parser.parse_args()

    # Start the monitoring loop from scheduler.py
    scheduler_main(
        interval=args.interval,
        count=args.count,
        dry_run=args.dry_run,
        verbose=args.verbose
    )
