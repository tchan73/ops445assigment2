#!/usr/bin/env python3
# Vishwanand Doobay
# OPS 445 Assignment 2 
# Date: 2025-08-05

import logging
import time
import json
from Monitor import collect_metrics

# Configure logging
logging.basicConfig(
    filename='system_monitor.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Default thresholds
THRESHOLDS = {
    'cpu_percent': 85.0,        # CPU usage threshold (%)
    'memory_used_ratio': 0.90,  # Memory used threshold (90%)
    'disk_used_ratio': 0.90     # Disk usage threshold (90%)
}


def check_thresholds(metrics):
    """Check system metrics against thresholds and return alerts and detailed status messages."""
    alerts = []
    details = []

    # CPU
    cpu = metrics['cpu_percent']
    details.append(f"CPU Usage: {cpu:.2f}%")
    if cpu > THRESHOLDS['cpu_percent']:
        alerts.append(f" High CPU usage: {cpu:.2f}%")

    # Memory
    used = metrics['memory']['used']
    available = metrics['memory']['available']
    total = used + available
    mem_usage_ratio = used / total if total else 0
    mem_usage_percent = mem_usage_ratio * 100
    details.append(f"Memory Usage: {mem_usage_percent:.2f}% ({used / (1024**2):.1f}MB used / {total / (1024**2):.1f}MB total)")
    if mem_usage_ratio > THRESHOLDS['memory_used_ratio']:
        alerts.append(f" High memory usage: {mem_usage_percent:.2f}%")

    # Disk
    for mount, info in metrics['disk'].items():
        disk_pct = info['percent']
        details.append(f"Disk Usage on {mount}: {disk_pct:.2f}% (Used: {info['used'] / (1024**3):.2f}GB / Total: {info['total'] / (1024**3):.2f}GB)")
        if disk_pct > THRESHOLDS['disk_used_ratio'] * 100:
            alerts.append(f" High disk usage on {mount}: {disk_pct:.2f}%")

    return alerts, details


def main(interval=5, count=None):
    """Main monitoring loop that logs and prints system status with alerts."""
    i = 0
    try:
        while True:
            metrics = collect_metrics()
            alerts, details = check_thresholds(metrics)

            # Timestamped header
            timestamp = metrics['timestamp']
            header = f"\n==== System Status @ {timestamp} ===="
            print(header)
            logging.info(header)

            # Log and print detailed metrics
            for line in details:
                print("INFO:", line)
                logging.info(line)

            if alerts:
                for alert in alerts:
                    print("ALERT:", alert)
                    logging.warning(alert)
            else:
                print("INFO: All systems within normal thresholds.")
                logging.info("All systems within normal thresholds.")

            #log raw metrics as JSON
            logging.debug("Full metrics snapshot:\n" + json.dumps(metrics, indent=2))

            i += 1
            if count and i >= count:
                break
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\nMonitoring interrupted by user.")
        logging.info("Monitoring interrupted by user.")


if __name__ == '__main__':
    main(interval=5, count=None)
