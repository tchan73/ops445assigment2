#!/usr/bin/env python3
# Vick Panchal
# OPS 445 Assignment 2
# Date: 2025-08-06
# Scheduler for system monitoring checks using interval loop

import time
import argparse
from Monitor import collect_metrics
from monitoralerts import check_thresholds
from alert import send_email_alert

def main(interval=60, count=None, dry_run=False, verbose=False):
    i = 0  # Track how many checks have been done

    try:
        while True:
            print(f"\n[INFO] Running system check #{i+1}")
            metrics = collect_metrics()  # Collect latest system metrics
            alerts, details = check_thresholds(metrics)  # Compare metrics to thresholds

            # Show full system status only if verbose is enabled
            if verbose:
                print("==== System Status ====")
                for line in details:
                    print("INFO:", line)

                if alerts:
                    for alert in alerts:
                        print("ALERT:", alert)
                else:
                    print("INFO: All systems within normal thresholds.")

            # Send email alert if needed
            if alerts and not dry_run:
                timestamp = metrics['timestamp']
                send_email_alert(alerts, timestamp)

            i += 1
            if count and i >= count:
                break

            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n[INFO] Monitoring loop interrupted by user.")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Schedule system monitoring checks at custom intervals.'
    )
    parser.add_argument(
        '--interval', '-i',
        type=int,
        default=60,
        help='Interval in seconds between each monitoring check (default: 60)'
    )
    parser.add_argument(
        '--count', '-c',
        type=int,
        help='Number of monitoring checks to run (default: infinite)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Run checks but do not send email alerts (for testing)'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Print full system status output (for testing)'
    )

    args = parser.parse_args()
    main(interval=args.interval, count=args.count, dry_run=args.dry_run, verbose=args.verbose)
