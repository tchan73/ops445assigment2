#!/usr/bin/env python3
# Thomas Chan
# OPS 445 ASSIGNMENT 2
# Date Created: 2025/08/04
# Lab: Metric Collection Script with psutil + subprocess diagnostics

#  Import modules for command-line parsing, JSON handling, subprocess management, time/date operations, and system monitoring

import argparse
import json
import subprocess
import time
import datetime
import psutil


def run_diagnostics():
    # Define a set of system diagnostic commands (kernel info, disk usage, network routes) to execute later
    commands = {
        'uname':       ['uname', '-a'],         # Get Kernel and OS info
        'disk_usage':  ['df', '-h'],            # Show disk usage in readable format
        'net_routes':  ['ip', 'route', 'show'], # List the Kernel's IP routing table 
        
    }
    # (ERROR CHECKING) Execute each diagnostic command, capture its output or error, split into lines, and store the results in a dictionary
    results = {}
    for name, cmd in commands.items():
        try:
            completed = subprocess.run(cmd, capture_output=True, text=True)
            text = completed.stdout.strip() or completed.stderr.strip()
        except Exception as e:
            text = f"Error running {name}: {e}"
        results[name] = text.splitlines()
    return results


def collect_metrics():
    # Gather current timestamp, CPU utilization, memory usage, and per-mount disk statistics into structured metrics

    timestamp = datetime.datetime.now().isoformat()         # Gathering of the current date and time

    
    cpu_pct = psutil.cpu_percent(interval=None)             # Instant value of the CPU Usage Load

   
    vm = psutil.virtual_memory()                            # Retrieve virtual memory statistics and record used and available memory amounts
    memory = {'used': vm.used, 'available': vm.available}

    
    disk = {}                                               # Iterate over all mounted filesystems, retrieve their total, used, free space and usage percentage, and store by mount point
    for part in psutil.disk_partitions():
        usage = psutil.disk_usage(part.mountpoint)
        disk[part.mountpoint] = {
            'total': usage.total,
            'used': usage.used,
            'free': usage.free,
            'percent': usage.percent
        }

    # Network I/O counters
    net_io = psutil.net_io_counters()._asdict()

    # System uptime
    uptime = time.time() - psutil.boot_time()

    # Diagnostics via shell
    diagnostics = run_diagnostics()

    # Return a consolidated dictionary of all collected metrics and diagnostics

    return {
        'timestamp':      timestamp,
        'cpu_percent':    cpu_pct,
        'memory':         memory,
        'disk':           disk,
        'network_io':     net_io,
        'uptime_seconds': uptime,
        'diagnostics':    diagnostics,
    }

# Repeatedly collect and print system metrics.

def main(interval: float, count: int = None):

    i = 0                                               # Initialize a counter to track how many times we've polled
    try:
        while True:                                     # Loop until we've reached the optional count limit or indefinitely if count is None    
            metrics = collect_metrics()                 # 1) Gather latest metrics (CPU, memory, disk, network, uptime, diagnostics)    
            print(json.dumps(metrics, indent=2))        # 2) Print the collected metrics as nicely indented JSON
            i += 1                                      # 3) Update the poll counter
            if count and i >= count:                    # 4) If a max count was provided and we've hit it, break out of the loop       
                break                                   # 5) Pause execution for the specified interval before next iteration
            time.sleep(interval)            
    except KeyboardInterrupt:
        print("\nPolling stopped by user.")              # Handle user pressing Ctrl+C: stop polling cleanly


if __name__ == '__main__':  # Only execute this block when the script is run directly
    parser = argparse.ArgumentParser(  # Create parser for command-line options
        description='Poll system metrics with psutil and subprocess diagnostics (excluding process list).'  # Help text shown in `--help`
    )
    parser.add_argument(  # Define polling interval option
        '-i', '--interval',
        type=float,
        default=5.0,  # Default to 5 seconds between polls
        help='Interval (s) between polls (default: 5)'
    )
    parser.add_argument(  # Define optional poll count limit
        '-c', '--count',
        type=int,  # Must be an integer
        help='Number of polls before exit (default: infinite)'
    )
    args = parser.parse_args()  # Parse the provided CLI arguments
    main(interval=args.interval, count=args.count)  # Start polling with those parameters
